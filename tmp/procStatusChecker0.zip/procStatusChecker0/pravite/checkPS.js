var fs = require("fs");
var lookupPS = require('./lookupPS.js');
var Q = require('q');


module.exports = function(){
  var deferred = Q.defer() ;
  fs.readFile( "./pravite/" + "devlist.json", 'utf8', function (err, devlist) {
    //console.log("device list:",devlist);
    var resultJson ;

    if (err){
      resultJson = {"area":"Err","path":"Err","status":0} ;
      console.log(err) ;
      var ary = [resultJson,psList];
      deferred.reject(ary);
    }

    lookupPS().then(function(psList){
      resultJson = checkFromList(JSON.parse(devlist),psList) ;
      var ary = [resultJson,psList];
      deferred.resolve(ary) ;
    },function(psErr){
      resultJson = {"area":"Err","name":"Err","status":0} ;
      var ary = [resultJson,psList];
      console.log(psErr) ;
      deferred.reject(ary);
    });



  });
  return deferred.promise ;

};

var checkFromList = function(devlist, psList){//(list for check),(current ps list)
  var checkResult = [] ; // final result , init first
  devlist.forEach(function(dev, devIndex, devArray){
    var found = false ;
    psList.forEach(function(ps,psIndex,psArray){
      if ( (dev.path == ps.command.substring(1, ps.command.length-1))
		|| (dev.path == ps.command) ){
        var upObj = {} ;
        upObj["area"] = dev.area ;
        upObj["name"] = dev.name ;
        upObj["status"] = 1 ;
        checkResult.push(upObj) ;
        found = true ;
      }
    });
    if (!found){
      var downObj = {} ;
      downObj["area"] = dev.area ;
      downObj["name"] = dev.name ;
      downObj["status"] = 0 ;
      checkResult.push(downObj) ;
    }

  } ) ;

  return checkResult ;
};
