var ps = require('./ps_node.js');
var Q = require('q');
module.exports = function() {
    var deferred = Q.defer() ;
    ps.lookup({
      // command: 'node'
    }, function(err, resultList) {
      if (err) {
        deferred.reject(err) ;
      }
      //console.log("resultList:"+ JSON.stringify(resultList));
      deferred.resolve(resultList) ;
    });
    return deferred.promise ;
  } ;
