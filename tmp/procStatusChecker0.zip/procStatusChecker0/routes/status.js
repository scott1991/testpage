var express = require('express');
var router = express.Router();
var Q = require('q');
var checkPS = require('../pravite/checkPS.js');

/* GET users listing. */
router.get('/', function(req, res, next) {
  // res.send('respond with a resource');
  var view = 'layout' ;
  checkPS().then(function(result){
    //console.log(result);
    renderFunc(res,view,result) ;
  },function(err){
    console.log(err) ;
    renderFunc(res,view,err) ;
  }) ;

  // res.json({a:"ssss",b:123});
});
var renderFunc = function( res,view,ary ){
  var vars = {};
  vars['title'] = 'status' ;
  // vars['body'] = JSON.stringify(obj);
  vars['ary'] = ary[0] ;
  vars['psList'] = ary[1] ;
  //console.log(ary);

  res.render(view, vars);
}

module.exports = router;
