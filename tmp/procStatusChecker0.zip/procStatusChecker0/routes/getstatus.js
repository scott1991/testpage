var express = require('express');
var router = express.Router();
var Q = require('q');
var checkPS = require('../pravite/checkPS.js');

/* GET users listing. */
router.get('/', function(req, res, next) {
 checkPS().then(function(result){
    res.json(result[0]) ;
  },function(err){
    res.json(err[0]) ;
  }) ;
  // res.json({a:"ssss",b:123});
});


module.exports = router;
