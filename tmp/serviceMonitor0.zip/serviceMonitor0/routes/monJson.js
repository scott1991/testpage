var express = require('express');
var router = express.Router();
var http = require('http');
var newestStatus = require('../pravite/newestStatus.json') ;


/* GET home page. */
router.get('/', function(req, res, next) {

  var returnJson = {} ;
  returnJson["gwData"] = newestStatus.DeviceGW ;
  returnJson["gwTime"] = newestStatus.gwTime ;
  returnJson["webData"] = newestStatus.WebServers ;
  returnJson["webTime"] = newestStatus.webTime ;

  // var gwTime = new Date(newestStatus.gwTime) ;
  // var webTime = new Date(newestStatus.webTime) ;
  res.json(returnJson);
});

  // repeatTimer();
module.exports = router;
