var express = require('express');
var router = express.Router();
var http = require('http');
var newestStatus = require('../pravite/newestStatus.json') ;
var _ = require('lodash');


/* GET home page. */
router.get('/', function(req, res, next) {

  // res.json(newestStatus);
  var gwTime = new Date(newestStatus.gwTime) ;
  var webTime = new Date(newestStatus.webTime) ;

  // var gwAreas = _.uniqBy(newestStatus.DeviceGW, "area");

  var DataByArea = {} ;
  // gwAreas.forEach(function(item){
  //   DataByArea[item]
  // })

  newestStatus.DeviceGW.forEach(
    function(item){
      if (_.has(DataByArea,item.area)){ // if (DataByArea.item.area != undfined)
        DataByArea[item.area].push({"status":item.status,"name":item.name}) ;
      }else{
        DataByArea[item.area] = [] ;
        DataByArea[item.area].push({"status":item.status,"name":item.name}) ;
      }
  })


  res.render('monitor', {
  title: 'Checker',
  gwData: newestStatus.DeviceGW,
  gwTime: gwTime.toLocaleString(),
  webData: newestStatus.WebServers,
  webTime: webTime.toLocaleString(),
  DataByArea:DataByArea
});
});

  // repeatTimer();
module.exports = router;
