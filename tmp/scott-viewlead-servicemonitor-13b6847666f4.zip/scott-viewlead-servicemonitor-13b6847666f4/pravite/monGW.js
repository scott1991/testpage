var request = require('request');
var newestStatus = require('./newestStatus.json') ;
var config = require('../config.json');

module.exports = function(){
  request(config.deviceGwAddr, function (error, response, body) {
    var timestemp = new Date();
    if (!error && response.statusCode == 200) {
      body["gwTime"]=timestemp.getTime();
      newestStatus.DeviceGW = JSON.parse(body) ;
      newestStatus.gwTime = timestemp.getTime();
      console.log(timestemp.toLocaleString()) ;
      logDevice(JSON.parse(body));
    }
    if (error){
      newestStatus.DeviceGW = [{"area":"All","name":"All Device Error","status":0}] ;
      console.log(timestemp.toLocaleString(),"\n\t\t",newestStatus.DeviceGW[0]) ;
      newestStatus.gwTime = timestemp.getTime();
    }

  });
};

var logDevice = function( jsonAry ){
  jsonAry.forEach(function(devObj){
    console.log("\t\t",devObj);
  })
}
