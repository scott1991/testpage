var request = require('request');
var config = require('../config.json');
var newestStatus = require('./newestStatus.json');

module.exports = function() {
  if (newestStatus.WebServers.length == 0) {
    config.websites.forEach(function(website) {
      var tmpObj = {};
      tmpObj["area"] = website.area;
      tmpObj["url"] = website.url ;
      tmpObj["name"] = website.name;
      tmpObj["status"] = 0;
      newestStatus.WebServers.push(tmpObj);
    })
  } // if not a empty list, copy in )


  var timestemp = new Date();
  newestStatus.WebServers.forEach(function(webStatus) {
    request(webStatus.url, function(error, response, body) {
      if (!error && response.statusCode == 200) {
        webStatus.status = 1 ;
        console.log(timestemp.toLocaleString(),webStatus.name,"\tresponse:",response.statusCode);
      }
      if (error) {
        webStatus.status = 0 ;
        console.log(timestemp.toLocaleString(),webStatus.name,"\tresponse:",error.code);
      }

    });
  });

  newestStatus["webTime"] = timestemp.getTime();

};
